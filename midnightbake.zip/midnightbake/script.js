// ALL SCREENS
const screens = document.querySelectorAll(".screen");

// BUTTONS
const getStartedBtn = document.getElementById("getStartedBtn");
const customerLogin = document.getElementById("customerLogin");
const businessLogin = document.getElementById("businessLogin");
const buyNowBtn = document.getElementById("buyNowBtn");
const payBtn = document.getElementById("payBtn");

// VIEW PRODUCT BUTTONS
const viewButtons = document.querySelectorAll(".view-product");

// BOTTOM NAV BUTTONS
const navButtons = document.querySelectorAll(".bottom-nav button");

// SHOW SCREEN FUNCTION
function showScreen(screenId) {
    screens.forEach(screen => {
        screen.classList.remove("active");
    });

    document.getElementById(screenId).classList.add("active");
}

// SPLASH -> LOGIN
if (getStartedBtn) {
    getStartedBtn.addEventListener("click", () => {
        showScreen("login-screen");
    });
}

// CUSTOMER LOGIN -> HOME
if (customerLogin) {
    customerLogin.addEventListener("click", () => {
        showScreen("home-screen");
    });
}

// BUSINESS LOGIN -> DASHBOARD
if (businessLogin) {
    businessLogin.addEventListener("click", () => {
        showScreen("business-screen");
    });
}

// PRODUCT DETAILS
viewButtons.forEach(button => {
    button.addEventListener("click", () => {
        showScreen("product-screen");
    });
});

// PRODUCT -> CHECKOUT
if (buyNowBtn) {
    buyNowBtn.addEventListener("click", () => {
        showScreen("checkout-screen");
    });
}

// CHECKOUT -> SUCCESS
if (payBtn) {
    payBtn.addEventListener("click", () => {

        payBtn.innerHTML = "Processing Payment...";

        setTimeout(() => {
            showScreen("success-screen");
        }, 1500);

    });
}

// BOTTOM NAVIGATION
navButtons[0].addEventListener("click", () => {
    showScreen("home-screen");
});

navButtons[1].addEventListener("click", () => {
    showScreen("home-screen");
});

navButtons[2].addEventListener("click", () => {
    showScreen("success-screen");
});

navButtons[3].addEventListener("click", () => {
    showScreen("profile-screen");
});

// FLASH SALE TIMER
let totalSeconds = 6300; // 1h 45m

function updateTimer() {

    const timers = document.querySelectorAll(".timer");

    let hours = Math.floor(totalSeconds / 3600);
    let minutes = Math.floor((totalSeconds % 3600) / 60);
    let seconds = totalSeconds % 60;

    let timeText =
        "⏳ " +
        String(hours).padStart(2, "0") +
        ":" +
        String(minutes).padStart(2, "0") +
        ":" +
        String(seconds).padStart(2, "0");

    timers.forEach(timer => {
        timer.innerHTML = timeText;
    });

    if (totalSeconds > 0) {
        totalSeconds--;
    }
}

setInterval(updateTimer, 1000);
updateTimer();

// BUSINESS FLASH SALE BUTTON
const flashSaleBtn = document.querySelector(".add-item button");

if (flashSaleBtn) {

    flashSaleBtn.addEventListener("click", () => {

        const inputs = document.querySelectorAll(".add-item input");

        let product = inputs[0].value;
        let qty = inputs[1].value;
        let discount = inputs[2].value;

        if (
            product === "" ||
            qty === "" ||
            discount === ""
        ) {
            alert("Please fill all fields");
            return;
        }

        alert(
            "Flash Sale Started!\n\n" +
            product +
            "\nQuantity: " +
            qty +
            "\nDiscount: " +
            discount +
            "%"
        );

        inputs[0].value = "";
        inputs[1].value = "";
        inputs[2].value = "";
    });

}

// LOGOUT
const profileButtons = document.querySelectorAll(".profile-box button");

if (profileButtons.length > 1) {

    profileButtons[1].addEventListener("click", () => {

        let confirmLogout = confirm(
            "Are you sure you want to logout?"
        );

        if (confirmLogout) {
            showScreen("login-screen");
        }

    });

}

// ORDER HISTORY BUTTON
if (profileButtons.length > 0) {

    profileButtons[0].addEventListener("click", () => {

        alert(
            "Order History\n\n" +
            "#MB12345 - Chocolate Croissant\n" +
            "₹48\n\n" +
            "#MB12346 - Blueberry Muffin\n" +
            "₹36"
        );

    });

}

// DEMO NOTIFICATION
setTimeout(() => {

    if (
        document.getElementById("home-screen")
            .classList.contains("active")
    ) {

        alert(
            "🔥 Fresh bakes near you are now on Flash Sale!\n\n" +
            "Up to 70% OFF"
        );

    }

}, 5000);